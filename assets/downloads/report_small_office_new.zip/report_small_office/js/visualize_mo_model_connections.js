// Variable to identify selection of nodes
var node_selected = false;

// Compute the distinct nodes from the links.
links.forEach(function(link) {
  link.source = nodes[link.source] || (nodes[link.source] = {name: link.source});
  link.target = nodes[link.target] || (nodes[link.target] = {name: link.target});
});

// Create visualization
var width = window.innerWidth*0.75,
    height = window.innerHeight*0.75;

var force = d3.layout.force()
    .nodes(d3.values(nodes))
    .links(links)
    .size([width, height])
    .linkDistance(100)
    .charge(-500)
    .on("tick", tick)
    .start();

var svg = d3.select("#container").append("svg")
    //better to keep the viewBox dimensions with variables
    .attr("viewBox", "0 0 " + width + " " + height )
    .attr("preserveAspectRatio", "xMidYMid meet");
    
var canvas = svg.append("g")
    .attr("class", "canvas");

// TODO: Fix the zooming in the future...
//svg.call(d3.behavior.zoom().on("zoom", redraw));

var path = canvas.append("g").selectAll("path")
    .data(force.links())
  .enter().append("path")
    .attr("class", function(d) { return "link " + d.type; });
    
var circle = canvas.append("g").selectAll("circle")
    .data(force.nodes())
  .enter().append("circle")
    .attr("r", 10)
    .on("click", mouseclick)
    .call(force.drag)
    .attr("class", function(d) { return "circle " + d.type; })
    .attr("data_id", function(d) {return d.name;})
    .attr("data_ix", function(d) {return d.index;})
    .attr("data_type", function(d) {return d.type;});

var text = canvas.append("g").selectAll("text")
    .data(force.nodes())
  .enter().append("text")
    .attr("x", 8)
    .attr("y", ".31em")
    .text(function(d) { return d.name; });


var text_links = canvas.append("g").selectAll("text")
    .data(force.links())
  .enter().append("text")
    .attr("dx", 1)
    .attr("dy", ".32em")
    .text(function (d) {
    	if (d.index_source && d.index_target){
    		txt = "("+d.index_source + ", " + d.index_target + ")";
    	}else if (d.index_source && !d.index_target){
    		txt = "("+d.index_source + ", )";
    	}else if (!d.index_source && d.index_target){
    		txt = "( , " + d.index_target + ")";
    	}else{
    		txt = ""
    	}
    	return txt;
    	});

function mouseclick() {

    // Just on double click
    if (event.detail == 2){
        d3.event.stopPropagation();
        
        var opacity_value = 0.1;
    
        // Toggle the boolean value
        node_selected = !node_selected;
        
        // Identify the node that received the click
        var node_clicked = $(this);
        var node_clicked_id = parseInt(node_clicked.attr("data_ix"));
    
        if (node_selected){
            var neighbours = [];
            
            path.style("opacity", function(o){
                if (o.source.index === node_clicked_id || o.target.index === node_clicked_id){
                    if (neighbours.indexOf(o.source.index) == -1){ neighbours.push(o.source.index);}
                    if (neighbours.indexOf(o.target.index) == -1){ neighbours.push(o.target.index);}
                    return 1.0;
                }else{
                    return opacity_value;
                }
            });
            
            var neighbours_2 = neighbours.slice();
            path.style("opacity", function(o){
                if (neighbours.indexOf(o.target.index) != -1 || neighbours.indexOf(o.source.index) != -1){
                    if (neighbours_2.indexOf(o.source.index) == -1){ neighbours_2.push(o.source.index);}
                    if (neighbours_2.indexOf(o.target.index) == -1){ neighbours_2.push(o.target.index);}
                    return 1.0;
                }else{
                    return opacity_value;
                }
            });
        
            circle.style("opacity", function(n){
                if (neighbours_2.indexOf(n.index) != -1){
                    return 1.0;
                }else{
                    return opacity_value;
                }
            });
        
            text.style("opacity", function(t){
                if (neighbours_2.indexOf(t.index) != -1){
                    return 1.0;
                }else{
                    return opacity_value;
                }
            });
            
            text_links.style("opacity", function(t){
                if (neighbours.indexOf(t.target.index) != -1 && neighbours.indexOf(t.source.index) != -1){
                    return 1.0;
                }else{
                    return opacity_value;
                }
            });
        
        }else{
            // visualize everything
            path.style("opacity", 1.0);
            circle.style("opacity", 1.0);
            text.style("opacity", 1.0);
            text_links.style("opacity", 1.0);
        }
    }    
}

// Use elliptical arc path segments to doubly-encode directionality.
function tick() {
  path.attr("d", linkArc);
  circle.attr("transform", transform);
  text.attr("transform", transform);
  text_links.attr("transform", transform_label);
}

function linkArc(d) {
  var dx = d.target.x - d.source.x,
      dy = d.target.y - d.source.y,
      dr = 0;
  return "M" + d.source.x + "," + d.source.y + "A" + dr + "," + dr + " 0 0,1 " + d.target.x + "," + d.target.y;
}

function transform(d) {
  return "translate(" + d.x + "," + d.y + ")";
}

function transform_label(d) {
  return "translate(" + (d.source.x + d.target.x)/2.0 + "," + (d.source.y + d.target.y)/2.0 + ")";
}

function redraw() {
    var translation = d3.event.translate,
        newx = translation[0],
        newy = translation[1];
    canvas.attr("transform",
        "translate(" + newx + "," + newy + ")" + " scale(" + d3.event.scale + ")");
}
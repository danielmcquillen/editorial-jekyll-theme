if ( ! Detector.webgl ) Detector.addGetWebGLMessage();

var container;
var camera, controls, scene, renderer;

init();
render();

function animate() {
    requestAnimationFrame(animate);
    controls.update();
}

function get_width() {
    return window.innerWidth*0.75;
}

function get_height() {
    return window.innerHeight*0.75;
}

function init() {

    camera = new THREE.PerspectiveCamera( 60, get_width() / get_height(), 1, 1000 );
    camera.position.z = 50;
    camera.position.y = 20;
    
    controls = new THREE.OrbitControls( camera );
    controls.damping = 0.2;
    controls.addEventListener( 'change', render );

    scene = new THREE.Scene();
    
    // Data representing the buildings                  
    
    /* Walls that are part of the building
    var material =  new THREE.MeshLambertMaterial( {
                color:0x000000,
                shading: THREE.FlatShading,
                transparent:true,
                opacity: 0.5,
                side: THREE.DoubleSide,
                needsUpdate: true});
    */
    // Create geometry, one for each wall/surface
    for (var key in walls){
    	
    	// For proper surfaces like walls (this excludes subsurfaces - they're holes)
    	var geom = new THREE.Geometry();
    	var count = 0;
    	var material =  new THREE.MeshBasicMaterial({ color: walls[key].color, 
    												  side: THREE.DoubleSide, 
    												  opacity: 0.8, 
    												  transparent:true});
    	
        for (var j = 0; j < walls[key].filled_surface.length; j++){
        
            var v1 = new THREE.Vector3(walls[key].filled_surface[j][0].x,walls[key].filled_surface[j][0].z,walls[key].filled_surface[j][0].y);
            var v2 = new THREE.Vector3(walls[key].filled_surface[j][1].x,walls[key].filled_surface[j][1].z,walls[key].filled_surface[j][1].y);
            var v3 = new THREE.Vector3(walls[key].filled_surface[j][2].x,walls[key].filled_surface[j][2].z,walls[key].filled_surface[j][2].y);
            
            geom.vertices.push(v1);
            geom.vertices.push(v2);
            geom.vertices.push(v3);
        
            geom.faces.push(new THREE.Face3(3*count, 3*count+1, 3*count+2));
            count += 1;
        }
        
        geom.computeFaceNormals();
    	var mesh = new THREE.Mesh( geom, material );
    	scene.add(mesh);
    	
    	// For subsurfaces (fill the holes)
    	geom = new THREE.Geometry();
    	count = 0;
    	material =  new THREE.MeshBasicMaterial({ color: 0x4183D7, 
    												  side: THREE.DoubleSide, 
    												  opacity: 0.5, 
    												  transparent:true} );
    	
        for (var j = 0; j < walls[key].sub_surfaces.length; j++){
        	for (var k = 0; k < walls[key].sub_surfaces[j].length; k++){
        	
        		var v1 = new THREE.Vector3(walls[key].sub_surfaces[j][k][0].x,walls[key].sub_surfaces[j][k][0].z,walls[key].sub_surfaces[j][k][0].y);
				var v2 = new THREE.Vector3(walls[key].sub_surfaces[j][k][1].x,walls[key].sub_surfaces[j][k][1].z,walls[key].sub_surfaces[j][k][1].y);
				var v3 = new THREE.Vector3(walls[key].sub_surfaces[j][k][2].x,walls[key].sub_surfaces[j][k][2].z,walls[key].sub_surfaces[j][k][2].y);
			
				geom.vertices.push(v1);
				geom.vertices.push(v2);
				geom.vertices.push(v3);
		
				geom.faces.push(new THREE.Face3(3*count, 3*count+1, 3*count+2));
				count += 1;
        	}
            
        }
        
        geom.computeFaceNormals();
    	mesh = new THREE.Mesh( geom, material );
    	scene.add(mesh);     
    }
    
    
    // Add the ground
	var floorMaterial = new THREE.MeshBasicMaterial( { color: 0x90C695, side: THREE.DoubleSide } );
	var floorGeometry = new THREE.PlaneGeometry(5000, 5000, 1, 1);
	var floor = new THREE.Mesh(floorGeometry, floorMaterial);
	floor.position.y = -0.5;
	floor.rotation.x = Math.PI / 2;
	scene.add(floor);
    
    // Add the lights
    light = new THREE.DirectionalLight( 0xffffff );
    light.position.set( 100, 100, 100 );
    scene.add( light );
    
    light = new THREE.DirectionalLight( 0xffffff );
    light.position.set( -100, 100, -100 );
    scene.add( light );
    
    light = new THREE.DirectionalLight( 0xffffff );
    light.position.set( -100, 100, 100 );
    scene.add( light );
    
    light = new THREE.DirectionalLight( 0xffffff );
    light.position.set( 100, 100, -100 );
    scene.add( light );

    light = new THREE.AmbientLight( 0x222222 );
    scene.add(light);


    // renderer
    renderer = new THREE.WebGLRenderer( { antialias: false } );
    renderer.setClearColor(0x1E8BC3);
    renderer.setPixelRatio( window.devicePixelRatio );
    renderer.setSize(get_width(), get_height());

    container = document.getElementById( 'container' );
    container.appendChild( renderer.domElement );

    // Add event listener
    window.addEventListener( 'resize', onWindowResize, false );

    animate();

}

function onWindowResize() {

    camera.aspect = get_width() / get_height();
    camera.updateProjectionMatrix();

    renderer.setSize( get_width(), get_height() );

    render();

}

function render() {

    renderer.render( scene, camera );

}